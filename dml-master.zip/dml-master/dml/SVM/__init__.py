"""

"""

import numpy as np
import scipy as sp
import pylab as py
from .svm import SVMC


__all__ = ['SVMC',
]