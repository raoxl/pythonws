from __future__ import division
import numpy as np
import scipy as sp
import pylab as py

	
class CRFC:
	def __init__(self,X,y,property=None):
		