"""

"""

import numpy as np
import scipy as sp
import pylab as py
from .naiveBayesian import NBC


__all__ = ['NBC'
]
