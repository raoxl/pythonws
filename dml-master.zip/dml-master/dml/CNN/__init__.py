import numpy as np
import scipy as sp

from .CNN import CNNC,LayerC

__all__ = ['CNNC'
]
